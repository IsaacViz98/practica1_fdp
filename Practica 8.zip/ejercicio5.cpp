#include <stdio.h>


int main()
{
            int i;
            printf("Introduzca n�mero del 1 al 5:");
    scanf("%d",&i);

     (i!=4 && i!=1)? printf("es primo"):printf("no es primo")   ;
	    
    return 0;
}
