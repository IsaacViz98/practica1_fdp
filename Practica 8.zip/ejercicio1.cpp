#include <conio.h>
#include <stdio.h>

int main()
{
    int edad;

    printf( "\n   Introduzca edad: " );
    scanf( "%d", &edad );
{

    if ( edad >= 0 )
        if ( edad <= 3 && edad >= 0)
        
    
            printf( "\n   BEBE, edad: %d", edad);
        else
            if ( edad < 13 && edad > 3 )
                printf( "\n   NI�O, edad: %d", edad );
            else
                if ( edad < 18 && edad > 12 )
                    printf( "\n   ADOLESCENTE, edad: %d", edad );
                else
                    if ( edad < 40 && edad > 17 )
                        printf( "\n   JOVEN, edad: %d", edad);
                    else
                        if ( edad < 60 && edad >39 )
                            printf( "\n   ADULTO, edad: %d", edad );
                        else
                        if (edad>59)
                            printf( "\n   ANCIANO, edad: %d", edad );
    
}
    
   
    return 0;
}
