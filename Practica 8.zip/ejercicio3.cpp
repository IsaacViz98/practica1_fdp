#include <stdio.h>
 
int main()
{
	float a;
	float b;
	float c;
 
	printf( "Introduce el primer lado: " );
	scanf( "%f", &a );
	printf( "Introduce el tercer lado: " );
	scanf( "%f", &b );
	printf( "Introduce el segundo lado: " );
	scanf( "%f", &c );
	
 
	if(a == 0 || a >= (b + c) || b >= (a + c) || c >= (b + a))
	{
		printf("\nNO se puede formar un triangulo");
	}else if(a == b && b == c)
	{
		printf("El triangulo es equilatero");
	}else if(a == b || a ==c || b==c )
	{
		
			printf ("es triangulo es iosceles\n");
		
	}else if( a!=b && a!=c && b!=c )
	{
	
			printf ("el triangulo es escaleno\n");
	}
	return 0;
}
